"use strict";
const menuButton = document.querySelector(".menu-toggle");
const mobileNav = document.getElementById("mobile-nav");
function closeMenu() { if (!menuButton || !mobileNav) return; mobileNav.hidden = true; menuButton.setAttribute("aria-expanded", "false"); menuButton.setAttribute("aria-label", "開啟導覽選單"); }
if (menuButton && mobileNav) { menuButton.addEventListener("click", () => { const open = menuButton.getAttribute("aria-expanded") === "true"; mobileNav.hidden = open; menuButton.setAttribute("aria-expanded", String(!open)); menuButton.setAttribute("aria-label", open ? "開啟導覽選單" : "關閉導覽選單"); }); mobileNav.querySelectorAll("a").forEach(link => link.addEventListener("click", closeMenu)); document.addEventListener("keydown", event => { if (event.key === "Escape") { closeMenu(); menuButton.focus(); } }); window.addEventListener("resize", () => { if (window.innerWidth > 850) closeMenu(); }); }
const sections = document.querySelectorAll("main section[id]");
const links = document.querySelectorAll(".desktop-nav a");
if ("IntersectionObserver" in window) { const observer = new IntersectionObserver(entries => { entries.forEach(entry => { if (!entry.isIntersecting) return; links.forEach(link => { const active = link.getAttribute("href") === "#" + entry.target.id; link.classList.toggle("active", active); if (active) link.setAttribute("aria-current", "location"); else link.removeAttribute("aria-current"); }); }); }, { rootMargin: "-15% 0px -60% 0px", threshold: 0 }); sections.forEach(section => observer.observe(section)); }
const printButton = document.querySelector(".print-button");
if (printButton) printButton.addEventListener("click", () => window.print());
